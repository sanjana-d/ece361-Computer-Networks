/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


#include <stdio.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <unistd.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <string.h>

int main(int argc, char** argv){
    
    
    
    //printf("Hello world from server\n");
   
    // create a socket
    int server_fd = socket(AF_INET, SOCK_DGRAM, 0);
    
    
    // bind to specific add/port number- https://man7.org/linux/man-pages/man2/bind.2.html
    struct sockaddr_in sockAdd;
    sockAdd.sin_family = AF_INET;
    sockAdd.sin_addr.s_addr = htonl(INADDR_ANY);
    //inet_pton(AF_INET, INADDR_ANY, &sockAdd.sin_addr);
    int portNumber = atoi(argv[1]);
    sockAdd.sin_port = htons(portNumber);
    memset(sockAdd.sin_zero, 0, sizeof(sockAdd.sin_zero) * sizeof(char));
    
    
    // bind the socket to an address
    int bind_success = bind(server_fd, (struct sockaddr*)&sockAdd, sizeof(sockAdd));
    while(bind_success == -1){
        // upon error prompt user to enter another port #
        int newPort;
        printf("ERROR: PORT NUMBER IN USE. PLEASE ENTER NEW PORT NUMBER: ");
        scanf("%d", &newPort);
        sockAdd.sin_port = htons(newPort);
        bind_success = bind(server_fd, (struct sockaddr*)&sockAdd, sizeof(sockAdd));
        portNumber = newPort;
    }
    
    printf("Server receiving on port %d\n", portNumber);
    
    
    char recieveBuf[100] = {0};
    struct sockaddr_storage emptyAdd;
    socklen_t len = sizeof(emptyAdd);
    ssize_t numBytesRecieved = recvfrom(server_fd, (void *)recieveBuf, 100, 0, (struct sockaddr*)&emptyAdd, &len);
    
    
    
    
    // send yes to client if buf=ftp
    // sockfd- fd from server socket
    // *buf - message char array which will be saved in a variable
    // len - size of(buf)
    // flags- 0
    // sockaddr- typecast our struct s to this before passing in
    // addrlen - len (from before)
    
    //ssize_t sendto(int sockfd, const void *buf, size_t len, int flags, const struct sockaddr *dest_addr, socklen_t addrlen); 
    if (strcmp(recieveBuf, "ftp") == 0){
        char sendBuf[] = "yes";
        ssize_t numBytesSent = sendto(server_fd, (void *)sendBuf, sizeof(sendBuf), 0, (struct sockaddr*)&emptyAdd, sizeof(emptyAdd));
    }
    else{
        char sendBuf[] = "no";
        ssize_t numBytesSent = sendto(server_fd, (void *)sendBuf, sizeof(sendBuf), 0, (struct sockaddr*)&emptyAdd, sizeof(emptyAdd));
    }
    
    //close(server_fd);
    return 0;
}
