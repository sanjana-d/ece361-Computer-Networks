/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

#include <stdio.h>
#include <stdlib.h>
#include <netinet/in.h>
#include <string.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>




void main(int argc, char** argv){
    
    
    
    // to listen need socket- https://man7.org/linux/man-pages/man2/socket.2.html
    // domain- AF_INET
    // type- SOCK_DGRAM
    // protocol- 0
    int client_fd = socket(AF_INET, SOCK_DGRAM, 0);
    
    
    // prompt ftp <filename>
    printf("Input a message in the following form -> ftp<filename>: ");
    
    char input[100];
    char fname[100];

    fgets(input, 100, stdin);
    
    //extract just the filename from input
    int size = strlen(input) - 4;
    memcpy(fname, &input[4], size);
    
    //get rid of any newline or tab
    strtok(fname, "\n\t"); 
    
    
    if (access(fname, F_OK) != 0){
        printf("File does not exist!\n");
        exit(0);
    }
    printf("File exists!\n");
               

    
    struct sockaddr_in sockAddrIn;
    sockAddrIn.sin_family = AF_INET;
    uint16_t portNumber = atoi (argv[2]);
    sockAddrIn.sin_port = htons(portNumber); //from command line
    //sockAddrIn.sin_addr = htonl(argv[1]); //from command line 
    inet_pton(AF_INET, argv[1], &(sockAddrIn.sin_addr));
    memset(sockAddrIn.sin_zero, 0, sizeof(sockAddrIn.sin_zero) * sizeof(char));
    socklen_t len = sizeof(sockAddrIn);
    
    char sendBuf[] = "ftp";
    ssize_t numBytesSent = sendto(client_fd, (void *)sendBuf, sizeof(sendBuf) * sizeof(char), 0, (struct sockaddr*) &sockAddrIn, len);

    
    char recvBuf[100] = {0}; 
    struct sockaddr_storage empty;
    size_t lenRecvBuf = 100;
    socklen_t addrLen = sizeof(empty);
    int flags = 0;
    
    ssize_t numBytesRecvd = recvfrom(client_fd, (void *)recvBuf, lenRecvBuf, flags, (struct sockaddr*) &empty, &addrLen); //this could be wrong for the last arg because might not have to pass in the &addrlen but just addrlen
    
    
    if (strcmp(recvBuf, "yes") == 0){
        printf("A file transfer can start.\n");
        close(client_fd);

    }else{
        //exit the program
        exit(0);
    }
}