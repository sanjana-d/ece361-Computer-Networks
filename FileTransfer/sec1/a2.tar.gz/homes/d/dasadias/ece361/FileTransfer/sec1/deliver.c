#include <stdio.h>
#include <stdlib.h>
#include <netinet/in.h>
#include <string.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#include "packet.h"
#include <time.h>


void convertPacketToString(char* buf, Packet *pack);
void send_to_server(char* fname, int client_fd, struct sockaddr_in sockAddrIn);

void main(int argc, char** argv){
    
    
    
    // to listen need socket- https://man7.org/linux/man-pages/man2/socket.2.html
    // domain- AF_INET
    // type- SOCK_DGRAM
    // protocol- 0
    int client_fd = socket(AF_INET, SOCK_DGRAM, 0);
    
    
    // prompt ftp <filename>
    printf("Input a message in the following form -> ftp <filename>: ");
    
    char input[100];
    char fname[100];

    fgets(input, 100, stdin);
    
    //extract just the filename from input
    int size = strlen(input) - 4;
    memcpy(fname, &input[4], size);
    
    //get rid of any newline or tab
    strtok(fname, "\n\t"); 
    
    
    if (access(fname, F_OK) != 0){
        printf("\nFile does not exist!");
        exit(0);
    }
    printf("\nFile exists!");
               

    
    struct sockaddr_in sockAddrIn;
    sockAddrIn.sin_family = AF_INET;
    uint16_t portNumber = atoi (argv[2]);
    sockAddrIn.sin_port = htons(portNumber); //from command line
    //sockAddrIn.sin_addr = htonl(argv[1]); //from command line 
    inet_pton(AF_INET, argv[1], &(sockAddrIn.sin_addr));
    memset(sockAddrIn.sin_zero, 0, sizeof(sockAddrIn.sin_zero) * sizeof(char));
    socklen_t len = sizeof(sockAddrIn);
    
    char sendBuf[] = "ftp";
    
    clock_t start_time, end_time;
    start_time = clock();

 
    ssize_t numBytesSent = sendto(client_fd, (void *)sendBuf, sizeof(sendBuf) * sizeof(char), 0, (struct sockaddr*) &sockAddrIn, len);

    
    char recvBuf[100] = {0}; 
    struct sockaddr_storage empty;
    size_t lenRecvBuf = 100;
    socklen_t addrLen = sizeof(empty);
    int flags = 0;
    
    ssize_t numBytesRecvd = recvfrom(client_fd, (void *)recvBuf, lenRecvBuf, flags, (struct sockaddr*) &empty, &addrLen); //this could be wrong for the last arg because might not have to pass in the &addrlen but just addrlen
    
    end_time = clock();

    double total_time = (double)(end_time - start_time)/CLOCKS_PER_SEC;

    printf("\nTotal round trip time is: %f\n", total_time);
    
    if (strcmp(recvBuf, "yes") == 0){
        printf("\nA file transfer can start.");
        

    }else{
        //exit the program
        exit(0);
    }

    
    printf("\nCalling send to server");
    //sending the file to server **note that empty will get populated by the servers info - so might have to pass that in instead 
    send_to_server(fname, client_fd, sockAddrIn);

    close(client_fd);
    
}

void send_to_server(char* fname, int client_fd, struct sockaddr_in sockAddrIn){
    FILE *file_ptr; 
    file_ptr = fopen(fname, "r");
    
    //move ptr to end of file
    fseek(file_ptr, 0, SEEK_END);
    
    int file_size = ftell(file_ptr);
   
    //move ptr back to beginning of file
    fseek(file_ptr, 0, SEEK_SET);
    //printf("\nCalculating total packets\n");
    int total_frag = 0;
    
    if(file_size%1000 == 0){
       total_frag = file_size/1000;
    }
    else{
        total_frag = file_size/1000 + 1;
    }
    
    //printf("\ntotal_frag is %d\n", total_frag);
    
    int frag_num = 1;
    
    while(frag_num<=total_frag){
        //printf("\nEntering loop\n");
        Packet pack; 
        
        //char fileData[1000];
        //setting the entire packet to 0s
        memset(pack.fileData, 0, 1000);
        //memset(fileData, 0, 1000);
        //printf("\nPoint A\n");
        //read from file
        fread((void*)pack.fileData, sizeof(char), 1000, file_ptr);
        //printf("\nPoint B\n");
        //populate the packet
        pack.total_frag = total_frag;
        pack.frag_no = frag_num;
        pack.filename = fname;
        //pack.fileData = fileData;
                
        //check if last packet
        if (frag_num == total_frag){ 
            //takes care of corner case if last packet is also of size 1000
            if (file_size%1000 == 0){
                pack.size = file_size%1000; 
            }else{
                pack.size = file_size%1000; 
            }
            
        }else{
            pack.size = 1000;
        }        
        
        //printf("\nConverting packet to string\n");
        char converted_str[5000];
        //convert packet into string
        int size_converted_str = sprintf(converted_str, "%d:%d:%d:%s:", pack.total_frag, pack.frag_no, pack.size, pack.filename);
        
        //can have converted_str + size_converted_str becuase of pointer aritmetic - and chars are size 1... 
        memcpy(converted_str + size_converted_str, pack.fileData, pack.size);
        //printf("\nConverted String: %s\n", converted_str);
        //sned pack to server
        socklen_t len = sizeof(sockAddrIn);
        
        printf("\nSending packet to server");
        ssize_t numBytesSent = sendto(client_fd, (void *)converted_str, pack.size + size_converted_str, 0, (struct sockaddr*) &sockAddrIn, len);
        
        //receive ACK from server
        char recvAckBuf[100] = {0}; 
        struct sockaddr_storage empty;
        size_t lenRecvAckBuf = 100;
        socklen_t addrLen = sizeof(empty);
        int flags = 0;

        printf("\nReceiving packet from server");
        ssize_t numBytesRecvd = recvfrom(client_fd, (void *)recvAckBuf, lenRecvAckBuf, flags, (struct sockaddr*) &empty, &addrLen); //this could be wrong for the last arg because might not have to pass in the &addrlen but just addrlen
        
        if (strcmp(recvAckBuf, "success") == 0){
            printf("Ack received!\n");
        }else{
            printf("Ack not recieved! Program exiting...\n");
            exit(0);
        }
        
        frag_num++;
              
                
    }
    
    
    

}
